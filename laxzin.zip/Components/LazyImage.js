import Image from "next/image";

const LazyImage = (props) => <Image {...props} />;

export default LazyImage;